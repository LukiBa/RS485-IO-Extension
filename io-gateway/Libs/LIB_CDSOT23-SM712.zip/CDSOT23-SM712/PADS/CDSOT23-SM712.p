*PADS-LIBRARY-PART-TYPES-V9*

CDSOT23-SM712 SOT95P230X117-3N I DIO 7 1 0 0 0
TIMESTAMP 2025.12.05.22.10.40
"Mouser Part Number" 652-CDSOT23-SM712
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bourns/CDSOT23-SM712?qs=FuI%252BOVLl4%2FLTY%2FGQ265RLA%3D%3D
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" CDSOT23-SM712
"Description" TVS Diode Dual Bi-Dir 7/12V 30KV SOT23 Bourns CDSOT23-SM712 Dual Bi-Directional TVS Diode, 400W peak, 3-Pin SOT-23
"Datasheet Link" 
"Geometry.Height" 1.17mm
GATE 1 3 0
CDSOT23-SM712
1 0 U 1
2 0 U 2
3 0 U 3

*END*
*REMARK* SamacSys ECAD Model
241162/1046115/2.50/3/3/Diode
